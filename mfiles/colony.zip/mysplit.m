global coloniesW comptimeW densmetricW
global coloniesR comptimeR densmetricR

cW=splitVector(coloniesW,4);
cpW=splitVector(comptimeW,4);
dW=splitVector(densmetricW,4);
cR=splitVector(coloniesR,4);
cpR=splitVector(comptimeR,4);
dR=splitVector(densmetricR,4);
