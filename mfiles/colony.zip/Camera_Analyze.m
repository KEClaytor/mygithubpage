% [COLONIES,COMPTIME,DENSMETRIC] = CAMERA_ANALYZE(METHOD,SOURCE,OD,ID,TMULT,SAVEOPTION)
% This program batch processes images sending one of the analysis routines
%   METHOD, SOURCE, OD, ID, TMULT and SAVEOPTION.  For details on these
%   variables, see the subfunctions listed below.
%
% See also: Camera_HRwtsh, Camera_HRrmax, Camera_morp, Camera_wtsh,
%           Camera_rmax.

% History
%   2008/06/24 - KEC - written for batch processing

%% 0 - Declare our function status
function [colonies,comptime,densmetric] = Camera_Analyze(method,source,od,id,tmult,saveopt)

%% 1 - Get user input for files to analyze
[fileName, pathName] = uigetfile('*.jpg','MultiSelect','on');      % Request the filename information from the sample
if iscell(fileName)
    fileName = sort(fileName);      % Put everything in proper order
    images = size(fileName,2);      % And get the number of images
else
    images = 1;                     % We did not do a multiple select, use only this image
end

switch saveopt      % which string to send 
    case 1          %   based on if we just want a count, or a saved count
        savedata = 'Save';
    case 0
        savedata = 'No';
end

% initalize some variables
numrows = images;
colonies = zeros(numrows,1);
comptime = zeros(numrows,1);
densmetric = zeros(numrows,1);

for method = 1:2
    %% 2 - Run the selected analysis method on each image
    for num = 1:images
        fprintf('\nProcessing Image: %g of %g\n',num,images);
        % put the filepath pointer together, we need to do it differently if
        % it's one of the multiple files, or if we have a single file selected
        if iscell(fileName)     % multifile select
            fullPathName = strcat(pathName,fileName{num});
            disp(['File name: ',fileName{num}])
        else                    % single file
            fullPathName = strcat(pathName,fileName);
            disp(['File name: ',fileName])
        end
        % Run the analysis on the images based on the method we chose
        switch method
            case 1
                [numcol,time,metric] = Camera_HRwtsh(fullPathName,source,od,id,tmult,savedata);
            case 2
                [numcol,time,metric] = Camera_HRrmax(fullPathName,source,od,id,tmult,savedata);

            case 3
                [numcol,time,metric] = Camera_morp(fullPathName,source,od,id,tmult,savedata);
            case 4
                [numcol,time,metric] = Camera_wtsh(fullPathName,source,od,id,tmult,savedata);
            case 5
                [numcol,time,metric] = Camera_rmax(fullPathName,source,od,id,tmult,savedata);
        end

            % Save the results for easy display later
            colonies(num,1) = numcol;
            comptime(num,1) = time;
            densmetric(num,1) = metric;
        
    end
end
beep;
