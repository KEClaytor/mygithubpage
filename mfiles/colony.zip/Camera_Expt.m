function varargout = Camera_Expt(varargin)
% CAMERA_EXPT M-file for Camera_Expt.fig
%      CAMERA_EXPT launches a window allowing one easy access to all data
%      capture and analysis functions of the webcam cell colony / plaque
%      counter.
%
% See also: CameraAq, Camera_Analyze, Camera_Stats

% History
%   2008/07/01 - KEC - Written, subsequently modified for updated
%     Camera_Analysis and added access to Camera_Stats

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Camera_Expt_OpeningFcn, ...
                   'gui_OutputFcn',  @Camera_Expt_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Camera_Expt is made visible.
function Camera_Expt_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Camera_Expt (see VARARGIN)

% Choose default command line output for Camera_Expt
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Camera_Expt wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Camera_Expt_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%% Runs the CameraAq program, which captures images
function button_capture_Callback(hObject, eventdata, handles)
% Gather and send file saving options
filepath = get(handles.display_filepath,'String');
while (isempty(filepath)) || (strcmp(filepath,'0'))
    button_filepath_Callback(hObject, eventdata, handles);
    filepath = get(handles.display_filepath,'String');
end
filename = get(handles.display_filename,'String');
while (isempty(filename)) || (strcmp(filename,''))
    button_filename_Callback(hObject, eventdata, handles);
    filename = get(handles.display_filename,'String');
end
sendvararg{1} = filepath;
sendvararg{2} = filename{1};
CameraAq(sendvararg);


%% Runs Camera_Analyze program, which analyzes an image sequence
function button_analyze_Callback(hObject, eventdata, handles)
method = get(handles.method,'Value');           % analysis method; HR watershed, HR reg max, morphological, watershed or regional max
colony = get(handles.radiocolony,'Value');      % colony = 1, plaque = 0;
od = str2double(get(handles.edit_od,'String')); % convert values for radius od and id to numbers
id = str2double(get(handles.edit_id,'String'));
tmult = str2double(get(handles.edit_tmult,'String'));   % convert value for manual threshold multiplier to a number
save = get(handles.check_save,'Value');         % do we want to save the output?
global colonies comptime densmetric
diary on        % Write the output to a file
[colonies,comptime,densmetric] = Camera_Analyze(method,colony,od,id,tmult,save) % Run the analysis method
diary off
% disply a helpful pointer in the command window to get the data back out.
fprintf('Type:\n  global colonies\n  global comptime\n  global densmetric\nTo access any of the above variables.\n')

%% Runs the Camera_Stats function, which shows
function button_stats_Callback(hObject, eventdata, handles)
% Run the stand-alone program Camera stats
% this allows for more specific editing and selecting cutoffs for the data
Camera_Stats()

%% Functions that get the filepath and name
function button_filepath_Callback(hObject, eventdata, handles)
dir = uigetdir;
set(handles.display_filepath,'String',dir);
function button_filename_Callback(hObject, eventdata, handles)
name = inputdlg('Filename','Save Options',1);
set(handles.display_filename,'String',name);


%% Extra crap that GUIDE puts in
function display_filepath_Callback(hObject, eventdata, handles)
function display_filepath_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function display_filename_Callback(hObject, eventdata, handles)
function display_filename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function method_Callback(hObject, eventdata, handles)
function method_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function source_Callback(hObject, eventdata, handles)
function source_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_od_Callback(hObject, eventdata, handles)
function edit_od_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_id_Callback(hObject, eventdata, handles)
function edit_id_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_tmult_Callback(hObject, eventdata, handles)
function edit_tmult_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function check_save_Callback(hObject, eventdata, handles)
