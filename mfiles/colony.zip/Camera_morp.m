% [COUNT,TIME,METRIC] = CAMERA_MORP(FULLPATH,SOURCE,OD,ID,TMULT,SAVE)
% Counts cell colonies / plaques using the watershed method.  Uses methods
%   develope for low resolution (640 x 480).  Latest version is outdated
%   and is NOT guarenteed to produce expected results.
%   FULLPATH is the path to the image file you would like to analyze,
%   SOURCE should either be 1 for colonies, or 0 for plaques (assumes
%   backlighting.  If using frontlighting reverse.).  OD is the outer
%   diameter of the identified RADIUS from sizeMask to consider as the
%   object of interest, while ID is the diameter for which there is no 
%   text.  TMULT is a manual threshold multiplication factor, and SAVE is a
%   string, if SAVE = 'save', then the data will be saved.  Otherwise just
%   a count will be returned.
%   COUNT is an integer of the number of colonies that could be identified
%   using this method, TIME is the time taken to perform the computation
%   and data save, and METRIC is an additional parameter to be returnd.
%   By default METRIC is the identified threshold divided by the average
%   value within the inner mask.
%
%  See also; Camera_Expt, Camera_Analyze, sizeMask, makeMask,
%            bwmorph, savecellimagedata

% History
% 2008/06/24 - KEC - Finished for the mid-term talks
% 2008/07/21 - KEC - Updated for packaging.

%% 0 - Declare function status
function [count,time,metric] = Camera_morp(fullpath,source,od,id,tmult,save)

if nargin < 6
    save = 'No';
    if nargin < 5
        tmult = 1;
        if nargin < 4
            id = .7;
            if nargin < 3
                od = .82;
            end
        end
    end
end

%% 1 - Load the image data
tic
disp('Loading image...')
ImageA = imread(fullpath);
info = imfinfo(fullpath);
switch info.ColorType
    case 'truecolor' %(RGB)
        ImageA = rgb2gray(ImageA);
end
I1 = im2double(ImageA);             % Convert to double
%figure, imshow(I), hold on;

% Make a mask over the center of the dish - ie, quickly exclude edge artifacts
disp('Generating mask...');
[radius,yc,xc]=sizeMask(I,2,0); % Change 0 --> 1 for plotting
[BWmask]=makeMask(I,radius*od,yc,xc);
[BWmasksm]=makeMask(I,radius*id,yc,xc);

if source == 1      % Source == 1  --> Colony Image, needs inverting
    % Invert the image
    disp('Inverting the image...')
    O = ones(1200,1600);
    Inv = imsubtract(O,I1);
else                % Otherwise, this is a plaque image - no inverting necessary
    Inv = I1;
end

% Do a top-hat transform, this removes the background
disp('Top-hat transforming...')
J1 = imtophat(Inv,strel('disk',15));

% Now threshold the image
disp('Applying thresholds...')
% Form two images;
% One of the inner region, from which we extract the threshold
M1 = immultiply(J1,im2double(BWmasksm));
avgin = sum(sum(M1))/sum(sum(BWmasksm));
Tholdx = graythresh(M1);
% And one from the full plate, which we threshold
M2 = immultiply(J1,im2double(BWmask));
C1 = im2bw(M2,Tholdx*tmult);

% Clean and open the BW image
disp('Cleaning mask...')
C2 = bwmorph(C1,'clean');
C3 = imopen(C2,strel('disk',2));

% Okay that's it, count 'em up.
[spotMap1,N1] = bwlabel(C3);

% % Comment this section to supress plotting
% colonyData = regionprops(spotMap1,'Centroid');
% cent = cat(1, colonyData.Centroid);   % Centroid coordinates
% if ~isempty(cent)
%     plot(cent(:,1),cent(:,2),'r.','MarkerSize',11)
% end

% Save the results if the user specified so...
if strcmpi(save,'save')
    disp('Saving data...')
    saveCellImageData(fullpath,1,I1,spotMap1)
    %saveCellImageData(fullfilepath,method,Original_Image,Label_Image)
end

count = N1;
metric = tholdx/avgin;
time = toc;
