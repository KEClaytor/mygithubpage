% [RADIUS,YC,XC] = SIZEMASK(IMAGE,METHOD,PLOT)
% Returns values for making a circular mask for IMAGE.  The circle is
%   centered at (XC,YC), with XC corresponding to columns, and YC to rows.
%   RADIUS is the radius of the largest, centralmost object in IMAGE.
%   Uses ones of three methods.  The first was optimized for a scanned
%   image (METHOD = 1), the second was optimzied for a low-resolution open
%   air webcam image (METHOD = 2), and the third was optimized for a high
%   resolution, backlit webcam image (METHOD = 3).
%
%  See also; imclose, imopen, imfill, bwtraceboundary.

function [radius,yc,xc]=sizeMask(Imagein,method,plot)

if nargin < 3   % default to no plotting
    plot = 0;
    if nargin < 2   % and high resolution webcam
        method = 5;
        if nargin < 1
            fprintf('At least one input argument must be specified.\nType ''help sizemask'' for more information.\n');
        end
    end
end

[row,col] = size(Imagein);

if method==1
    %% Morphological method optimized for the scanner
    % AKA we want to automatically generate the dish mask
    % Concerned with detecting the edges
    [junk threshold] = edge(Imagein, 'sobel');
    fudgeFactor = .5;
    BWs = edge(Imagein,'sobel', threshold * fudgeFactor);
    %figure, imshow(BWs), title('binary gradient mask');

    BWsdil = imdilate(BWs,strel('disk',5)); % Use a disk to dilate
    %pause(.01), imshow(not(BWsdil)), title('dilated mask');
    BWdfill = imfill(not(BWsdil), 'holes');
    BWdfill = imclose(BWdfill,strel('disk',10));
    %imshow(BWdfill), title('inverted filled mask');

    % Use a morphological open on the image, which erodes, then dilates it
    %    this gets us back to something that should look like the petri dish
    BWfinal = imopen(BWdfill,strel('disk',30));
    %imshow(BWfinal), title('ROI');

    % Select the center object
    BWfinal = bwselect(BWfinal,round(col/2),round(row/2));
    %imshow(BWfinal), title('Filled mask, Central Object Selected');

    [radius,yc,xc] = getRadius(BWfinal,row,col,plot);

elseif method==2
    %% Open-by-reconstruction method specialized for the webcam!
    % First do an open-by-reconstruction, this evens the background up
    Ie = imerode(Imagein,strel('disk',5));    % Generate the mask
    Iobr = imreconstruct(Ie,Imagein);         % Do the reconstruction

    % Now to a top-hat transform, this removes the background
    strelSize = 30; %input('Size for Strel disk: ');  % Use a disk size of 30, believe it or not, most of the stuff fits inside this disk
    J = imtophat(Iobr,strel('disk',strelSize));
    %figure, imshow(J), title('Background Removed');

    % Adjust the intensity of the image
    K = imadjust(J);
    %figure, imshow(K), title('Intensity Adjusted');

    % Threshold to grayscale
    Thold = graythresh(K);
    BW = im2bw(K,Thold/2);
    %figure, imshow(BW), title('BW Thresholded');

    % Now fill
    BWfill = imfill(BW, 'holes');
    %imshow(BWfill), title('Filled mask');

    % Select the center object
    BWfill = bwselect(BWfill,round(col/2),round(row/2));
    imshow(BWfill), title('Filled mask, Central Object Selected');

    % Get the radius
    [radius,yc,xc] = getRadius(BWfil,row,col,plot);

elseif method==3
    %% Morphological approach optimized for back-lit high resolution webcam images
    thold = graythresh(Imagein);
    IBW = im2bw(Imagein,thold/2);               % Threshold the image to BW
    IBWO = imopen(IBW,strel('disk',15));        % Separate any edge artifacts from the mainstay of the disk
    IBWOC = imclose(IBWO,strel('disk',15));     % Close any elements in the disk
    BW = bwselect(IBWOC,800,600);               % Select the central object
    BWf = imfill(BW,'holes');                   % and fill it in
    % Get the radius
    [radius,yc,xc] = getRadius(BWf,row,col,plot);

    %% Overflow methods, outdated, etc.
elseif method==5
    disp('Webcam method 5 outdated.  Use method 2 instead.')
    radius = 0; xc = 0; yc = 0;
else
    disp('Method not understood');
    radius = 0; xc = 0; yc = 0;
end

return

function [radius,yc,xc] = getRadius(BWfill,row,col,plot)
% The following code was taken from the tape demo...
sc = round(col/2);
sr = find(BWfill(:,sc), 1);
% Trace the boundary
connectivity = 8;
num_points   = round((row+col)*pi);
contour = bwtraceboundary(BWfill, [sr, sc], 'E', connectivity, num_points);
%    hold on;
%    plot(contour(:,2),contour(:,1),'g','LineWidth',2);
x = contour(:,2);
y = contour(:,1);
% solve for parameters a, b, and c in the least-squares sense by
% using the backslash operator
abc = [x y ones(length(x),1)] \ -(x.^2+y.^2);
a = abc(1); b = abc(2); c = abc(3);
% calculate the location of the center and the radius
xc = -a/2;
yc = -b/2;
radius = sqrt((xc^2+yc^2)-c);
% display the calculated center
%    plot(xc,yc,'yx','LineWidth',2);
if plot == 1
    % plot the entire circle
    theta = 0:0.01:2*pi;
    % use parametric representation of the circle to obtain coordinates
    % of points on the circle
    Xfit = radius*cos(theta) + xc;
    Yfit = radius*sin(theta) + yc;
    plot(Xfit, Yfit);
end
return