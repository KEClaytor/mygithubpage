function varargout = Camera_Stats(varargin)
% CAMERA_STATS M-file for Camera_Expt.fig
%      Calls up a figure with which you can select different stats to
%      display from a saved colony identification image (run from
%      Camera_Analyze).
%
% See also: Camera_Expt, Camera_Analyze, CameraAq

% History
%   KEC - 2008-07-18 - Wrote and finished the program.

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Camera_Stats_OpeningFcn, ...
                   'gui_OutputFcn',  @Camera_Stats_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

%% Introduction: opening and closing functions
% --- Executes just before Camera_Stats is made visible.
function Camera_Stats_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Camera_Stats (see VARARGIN)

% Choose default command line output for Camera_Stats
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);

% Turn off the axes
axes(handles.axes1);
axis off
axes(handles.axes2);
axis off

% UIWAIT makes Camera_Stats wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = Camera_Stats_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%% Body of the GUI

%% 1 - Loading data
function button_load_Callback(hObject, eventdata, handles)
[fileName, pathName] = uigetfile('*.jpg','Find Image file with data');
fullPath = [pathName,fileName];
fullDataPathW = [pathName,'results\',fileName(1:end-4),'_HRwtrshed_Label.mat'];
fullDataPathR = [pathName,'results\',fileName(1:end-4),'_HRregmax_Label.mat'];
% Load the image
% The following code deals with errors that could crop up
I = []; Label_Image = [];
try
    I = imread(fullPath);
    I_info = imfinfo(fullPath);
end
if isempty(I)
    errordlg('o_O   well that''s strange, I can''t load the image file.', 'No Image File');
end
% If we have troubles loading up the Label image....
% Check for the label image we want to load up
wtr = get(handles.radio_watershed,'Value');
rmx = get(handles.radio_regmax,'Value');
if wtr==1 && rmx==0
    method = 1;
elseif wtr==0 && rmx==1
    method = 2;
end
switch method
    case 1
        try
            load(fullDataPathW);
        end
    case 2
        try
            load(fullDataPathR);
        end
end
if isempty(Label_Image)
    % Give the user the option of running the data analysis.
    getdata = questdlg('Data Analysis was not saved, run now?','No Data File','Yes','No','No');
    switch getdata
        case 'Yes'
            type = questdlg('Type of image?','Image type','Colony','Plaque','Colony');
            switch type
                case 'Colony'
                    source = 1;
                case 'Plaque'
                    source = 2;
            end
            switch method
                case 1
                    [numcol,time,metric] = Camera_HRwtsh(fullPath,source,'save');
                case 2
                    [numcol,time,metric] = Camera_HRwtsh(fullPath,source,'save');
            end
        case 'No'
            set(handles.disp_filename,'String','No data found for selected file.');
            return
    end
end
% Update the display box
set(handles.disp_filename,'String',fileName);
% Update the data for the program.
handles.Image = I;
handles.Label = Label_Image;
% Find info and store it in the handles structure
colonyData = regionprops(Label_Image,'Area','BoundingBox','Centroid','Eccentricity','MajorAxisLength','MinorAxisLength','Orientation','Perimeter');
area = cat(1, colonyData.Area);
ecce = cat(1, colonyData.Eccentricity);
majaxis = cat(1, colonyData.MajorAxisLength);
minaxis = cat(1, colonyData.MinorAxisLength);
orien = cat(1, colonyData.Orientation);
peri = cat(1, colonyData.Perimeter);
bbox = cat(1, colonyData.BoundingBox);
cent = cat(1, colonyData.Centroid);
r = (bbox(:,3)+bbox(:,4))./4;
metric = peri./area.*r/2;
% Get some extra info about the image if the user wants it
if get(handles.check_intensity,'Value')
    if strcmpi(I_info.ColorType,'truecolor')
        % This is a color image, get the RGB info back out
        [totalI,averageI,arI,agI,abI] = getIntensityValues(I,Label_Image,1);
        colheaders = {'Area','Eccentricity','MajorAxisLength','MinorAxisLength','Orientation','Perimeter','Metric ~1','Total Intensity','Average Intensity','red Intensity','green Intensity','blue Intensity','Bounding Box row','Bounding Box cow','Bounding Box width','Bounding Box height','Centroid row','Centroid col'};
        data = [area,ecce,majaxis,minaxis,orien,peri,metric,totalI,averageI,arI,agI,abI,bbox,cent];
    else
        % This is NOT a color image, simply get the intensity back out, and
        %   discard the rest
        [totalI,averageI,arI,agI,abI] = getIntensityValues(I,Label_Image,0);
        colheaders = {'Area','Eccentricity','MajorAxisLength','MinorAxisLength','Orientation','Perimeter','Metric ~1','Total Intensity','Average Intensity','Bounding Box row','Bounding Box cow','Bounding Box width','Bounding Box height','Centroid row','Centroid col'};
        data = [area,ecce,majaxis,minaxis,orien,peri,metric,totalI,averageI,bbox,cent];
    end
else
    colheaders = {'Area','Eccentricity','MajorAxisLength','MinorAxisLength','Orientation','Perimeter','Metric ~1','Bounding Box row','Bounding Box cow','Bounding Box width','Bounding Box height','Centroid row','Centroid col'};
    data = [area,ecce,majaxis,minaxis,orien,peri,metric,bbox,cent];
end
stringtemp=[];
for k=1:length(colheaders)
    stringtemp = [stringtemp,'|',colheaders{k}];
end
stringtemp=stringtemp(2:end);
set(handles.popup_x,'String',stringtemp);
set(handles.popup_y,'String',stringtemp);
handles.colheaders = colheaders;
handles.data = data;
handles.path = pathName;
handles.name = fileName;
% Update handles structure
guidata(hObject, handles);
% And display the new plots.
updatePlots(hObject,handles);
% And set the total number counter
set(handles.disp_total,'String',num2str(size(data,1)));


%% 2 - Select which data to plot and replot upon making changes
% A change to either of the x or y data sets
function popup_x_Callback(hObject, eventdata, handles)
updatePlots(hObject,handles);   % New data selected, update accordingly
function popup_y_Callback(hObject, eventdata, handles)
updatePlots(hObject,handles);   % New data selected, update accordingly
% A change to our cutoff boundaries
function edit_xmin_Callback(hObject, eventdata, handles)
updatePlots(hObject,handles);   % Run the updater after we've clicked on a box
function edit_xmax_Callback(hObject, eventdata, handles)
updatePlots(hObject,handles);
function edit_ymin_Callback(hObject, eventdata, handles)
updatePlots(hObject,handles);
function edit_ymax_Callback(hObject, eventdata, handles)
updatePlots(hObject,handles);
function button_setcutoffs_Callback(hObject, eventdata, handles)
updatePlots(hObject,handles);
function button_getcutoffs_Callback(hObject, eventdata, handles)
% Get two clicks from the user on the graph window
[x,y] = ginput(2);
% Set the values in the boxes to those
set(handles.edit_xmin,'String',num2str(min(x)));
set(handles.edit_xmax,'String',num2str(max(x)));
set(handles.edit_ymin,'String',num2str(min(y)));
set(handles.edit_ymax,'String',num2str(max(y)));
updatePlots(hObject,handles);       % And run the updater

function button_plotI_Callback(hObject, eventdata, handles)
% Display a new figure of our image and overlay
updatePlots(hObject,handles,1);
function button_plotfig_Callback(hObject, eventdata, handles)
% Display a new figure of our cutoff values
updatePlots(hObject,handles,2);
function button_export_Callback(hObject, eventdata, handles)
% Export the data to an excel file
updatePlots(hObject,handles,3);

function updatePlots(hObject, handles, dispcase)
if nargin < 3
    dispcase = 0;
end
% Case zero -> we're looking at it in this figure
if dispcase == 0
    % Clear the current axes
    axes(handles.axes1); cla;
    axes(handles.axes2); cla;
elseif (dispcase == 1) || (dispcase == 2)
    figure;
end

% Get the data
colheaders = handles.colheaders;
data = handles.data;
% Obtain which values we wish to plot
xp = get(handles.popup_x,'Value');
yp = get(handles.popup_y,'Value');
% Now get the cutoff values
xmin = str2double(get(handles.edit_xmin,'String'));
xmax = str2double(get(handles.edit_xmax,'String'));
ymin = str2double(get(handles.edit_ymin,'String'));
ymax = str2double(get(handles.edit_ymax,'String'));
% Find the values that satisify our cutoffs
loc = find((data(:,xp) <= xmax) & (data(:,xp) >= xmin)...
         & (data(:,yp) <= ymax) & (data(:,yp) >= ymin));

% Good, now we plot the scatter plot
if (dispcase == 0) || (dispcase == 2)
    % Plot all values in red
    plot(data(:,xp),data(:,yp),'r.'); hold on;
    minxd = min(data(:,xp)); maxxd = max(data(:,xp));
    minyd = min(data(:,yp)); maxyd = max(data(:,yp));
    axis([minxd maxxd minyd maxyd]);
    % Overlay the cutoff values on the graph
    plot([xmin, xmax],[ymin, ymin],'b'); plot([xmin, xmax],[ymax, ymax],'b');
    plot([xmin, xmin],[ymin, ymax],'b'); plot([xmax, xmax],[ymin, ymax],'b');
    % Plot those that satisify our cutoffs in green
    plot(data(loc,xp),data(loc,yp),'g.');
    title('Scatterplot of Parameters');
    xlabel(colheaders(xp));
    ylabel(colheaders(yp));
end

% And we plot the image and overlay
if (dispcase == 0) || (dispcase == 1)
    % Now we deal with displaying the overlay
    % Start with showing the original image
    if dispcase == 0;   % Switch back to our in figure axes only if we need to
        axes(handles.axes1);
    end
    I = handles.Image;
    L = handles.Label;
    imshow(I); hold on;
    % Split the matrix up into two images
    % Those we want to keep
    LG = zeros(size(L));
    for k = loc'
        LG(find(L==k)) = k;
    end
    % And those that we do not
    LR = L - LG;
    % Plot those we want to keep in jet
    LGC = label2rgb(LG, @jet, 'k', 'shuffle');
    lgimage = imshow(LGC);
    set(lgimage, 'AlphaData', 0.3);
    % And those we don't care about in copper
    LRC = label2rgb(LR, @copper, 'k', 'shuffle');
    lrimage = imshow(LRC);
    set(lrimage, 'AlphaData', 0.3);
    title('Identified Overlay')
end

% Also update the little checkbox
set(handles.disp_kept,'String',num2str(size(loc,1)));

% The horror, we need to export to excel!
if dispcase == 3
    % We've alredy got colheaders and data, so we just need to get the rest
    % Form another column of which ones we decided to keep.
    good = zeros(size(data,1),1);
    good(loc) = 1;
    colheadersout = [colheaders,'Survived Cutoff'];
    dataout = [data,good];
    % Get the filepath name
    outpath = [handles.path,'results\',handles.name(1:end-4),'_Stats_Mod.csv'];
    % Write the data as an excel spreadsheet
    xlswrite(outpath,colheadersout,'Sheet1','A1')
    if ~isempty(data)
        xlswrite(outpath,dataout,'Sheet1','A2')
    end
end

%% Legacy
% crap GUIDE puts in that we don't delete for phear of retribution
function popup_x_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function popup_y_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function disp_kept_Callback(hObject, eventdata, handles)
function disp_kept_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function disp_total_Callback(hObject, eventdata, handles)
function disp_total_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function disp_filename_Callback(hObject, eventdata, handles)
function disp_filename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_xmin_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_xmax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_ymin_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_ymax_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function check_intensity_Callback(hObject, eventdata, handles)
