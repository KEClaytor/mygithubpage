function [BWout] = myreconstruct(marker,mask)
% IMAGE = MYRECONSTRUCT(MARKER,MASK)
%  Morphological reconstruction of a BW image (MASK), from starting pixels
%  (MARKER) such that distinct MARKER pixels result into distinct IMAGE
%  pixel groups, all constrained to the MASK.  Works somewhat like
%  IMRECONSTRUCT, except it preserves distinct MARKER pixels.
%
%  See also, BWMORPH, IMRECONSTRUCT.

BWoutold = (marker & mask);
BWout = (bwmorph(marker,'thicken',1) & mask);

while find(BWout-BWoutold)

    BWoutold = BWout;
    BWout = (bwmorph(BWout,'thicken',1) & mask);

end

return

