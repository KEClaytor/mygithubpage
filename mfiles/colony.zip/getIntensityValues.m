% [TOTALI,AVERAGEI,ARI,AGI,ABI] = GETINTENSITYVALUES(IMAGE,LABEL,COLOR)
% Calculates the total intensity values (TOTALI) and average intesnsity values
%   (AVERAGEI) for each LABEL region of an IMAGE sent to it.  If the image
%   is RGB, set COLOR = 1, to also return the average red (ARI), green
%   (AGI), and blue (ABI) intensities as well.  If the image is grayscale
%   set COLOR = 2, and these will be returned as zero vectors.
%
%  See also; save, getframe, imwrite, xlswrite.

function [totalI,averageI,arI,agI,abI] = getIntensityValues(Image,Label,color)

if nargin < 3
    color = 2;
end

numregions = max(max(Label));
totalI = zeros(numregions,1);
averageI = zeros(numregions,1);
arI = zeros(numregions,1);
agI = zeros(numregions,1);
abI = zeros(numregions,1);
h = waitbar(0,'Calculating intensity and component values');
for r = 1:numregions
    waitbar(r/numregions,h);
    if color==1
        % This is a truecolor RGB image, use RGB processing
        tmask = zeros(size(Label));
        tmask(find(Label==r)) = 1;
        npts = sum(sum(tmask));
        rIv = sum(sum(tmask.*im2double(Image(:,:,1))));
        gIv = sum(sum(tmask.*im2double(Image(:,:,2))));
        bIv = sum(sum(tmask.*im2double(Image(:,:,3))));
        arI(r) = rIv/npts;
        agI(r) = gIv/npts;
        abI(r) = bIv/npts;
        totalI(r) = rIv+gIv+bIv;
        averageI(r) = totalI(r)/npts;
    elseif color==2
        % This is a grayscale RGB image, arI, agI, abI have no meaning
        tmask = zeros(size(Label));
        tmask(find(Label==r)) = 1;
        tmask(find(Label==r)) = 1;
        cIv = sum(sum(tmask.*im2double(Image)));
        totalI(r) = cIv;
        averageI(r) = totalI(r)/npts;
    end
end
close(h);
return
