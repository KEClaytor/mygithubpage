% [BWMASK] = GENERATEMASK(IMAGE,RADIUS,YC,XC)
% Generates a mask centered at (XC,YC) (XC relates to column, yc to row) of
%   the same size as IMAGE with a radius of RADIUS.  Within the RADIUS
%   values are labeled high (1) and outside they are low (0).
%
%  See also; sizeMask.

function [BWmask]=makeMask(Imagein,radius,yc,xc)

%% Now generate a new mask based on the radius information
[row,col] = size(Imagein);
BWmask = zeros(row,col);
for r = 1:row
    for c = 1:col
        if sqrt((r-yc)^2+(c-xc)^2) <= radius
            BWmask(r,c) = 1;
        end
    end
end

return