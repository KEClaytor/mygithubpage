% SAVECELLIMAGEDATA(FILEPATH,METHOD,IMAGE,LABEL)
% Saves the label image as a .mat file for Camera_Stats, as well as a false
%   color colony map overlaid on the original image file, and the
%   statistics of the label image.  Different methods will be saved with
%   different identifiers in the name, so that other methods' data will not
%   be overwritten.
%   The filepath should be the full filepath to the image file of interest,
%   method is an integer corresponding to 1 = morphological (morpho), 2 =
%   watershed (wtrshed), 3 = regional max (regmax), 4 = HR watershed
%   (HRwtrshed), 5 = HR regional max (HRregmax).
%
%  See also; save, getframe, imwrite, xlswrite.

function saveCellImageData(fullfilepath,method,Original_Image,Label_Image)

% Assemble names, etc for saving
slash = max(strfind(fullfilepath,'\'));
generalname = fullfilepath(slash+1:end-4);
filepath=fullfilepath(1:slash);
% Make a directory called results if one does not exist
try
    mkdir(filepath,'results');
end
filepath = [filepath,'results\'];   % Add on this to another folder
% add in the analysis method to the data
switch method
    case 1
        pretag = '_morpho';
    case 2
        pretag = '_wtrshed';
    case 3
        pretag = '_regmax';
    case 4
        pretag = '_HRwtrshed';
    case 5
        pretag = '_HRregmax';
end

% First save the label image, as a .mat file this is the one that counts anyway
fileend = '_Label';
ofmt = '.mat';
outpath=strcat(filepath,generalname,pretag,fileend,ofmt);
save(outpath, 'Label_Image');

% Now prepare the text data (area, centroid location, etc) for export
colonyData = regionprops(Label_Image,'Area','BoundingBox','Centroid','Eccentricity','MajorAxisLength','MinorAxisLength','Orientation','Perimeter');
area = cat(1, colonyData.Area);
ecce = cat(1, colonyData.Eccentricity);
majaxis = cat(1, colonyData.MajorAxisLength);
minaxis = cat(1, colonyData.MinorAxisLength);
orien = cat(1, colonyData.Orientation);
peri = cat(1, colonyData.Perimeter);
bbox = cat(1, colonyData.BoundingBox);
cent = cat(1, colonyData.Centroid);
colheaders = {'Area','Eccentricity','MajorAxisLength','MinorAxisLength','Orientation','Perimeter','Bounding Box row','Bounding Box cow','Bounding Box width','Bounding Box height','Centroid row','Centroid col'};
data = [area,ecce,majaxis,minaxis,orien,peri,bbox,cent];

fileend = '_Stats';
ofmt = '.csv';
outpath=strcat(filepath,generalname,pretag,fileend,ofmt);
% Write the data as an excel spreadsheet
xlswrite(outpath,colheaders,'Sheet1','A1')
if ~isempty(data)
    xlswrite(outpath,data,'Sheet1','A2')
end

% Color label the Colony Image and export it overlaid on the original image
RGBFig = figure;
RGB = label2rgb(Label_Image, @jet, 'k', 'shuffle');
imshow(Original_Image)
hold on
himage = imshow(RGB);
set(himage, 'AlphaData', 0.3);
usloc = strfind(generalname,'_');
titlename = generalname;
titlename(usloc) = ' ';
title([titlename,' with False Color Colony Overlay: ',num2str(size(data,1)),' Colonies']);
outImage = getframe(RGBFig);
drawnow;
fileend = '_ID';
ofmt = '.jpg';
outpath=strcat(filepath,generalname,pretag,fileend,ofmt);
imwrite(outImage.cdata,outpath,'Quality',100);
close(RGBFig);

% Inform the user that we're done!
disp('Save successful!')

return
