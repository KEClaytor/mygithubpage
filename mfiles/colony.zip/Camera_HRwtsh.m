% [COUNT,TIME,METRIC] = CAMERA_HRRMAX(FULLPATH,SOURCE,OD,ID,TMULT,SAVE)
% Counts cell colonies / plaques using the watershed method.  Uses high
%   resolution (1600 x 1200) optimized methods.
%   FULLPATH is the path to the image file you would like to analyze,
%   SOURCE should either be 1 for colonies, or 0 for plaques (assumes
%   backlighting.  If using frontlighting reverse.).  OD is the outer
%   diameter of the identified RADIUS from sizeMask to consider as the
%   object of interest, while ID is the diameter for which there is no 
%   text.  TMULT is a manual threshold multiplication factor, and SAVE is a
%   string, if SAVE = 'save', then the data will be saved.  Otherwise just
%   a count will be returned.
%   COUNT is an integer of the number of colonies that could be identified
%   using this method, TIME is the time taken to perform the computation
%   and data save, and METRIC is an additional parameter to be returnd.
%   By default METRIC is the identified threshold divided by the average
%   value within the inner mask.
%
%  See also; Camera_Expt, Camera_Analyze, sizeMask, makeMask,
%            imregionalmax, myreconstruct, savecellimagedata

% History
% 2008/07/11 - KEC - Finished optimization for HR images

%% 0 - Declare function status
function [count,time,metric] = Camera_HRwtsh(fullpath,source,od,id,tmult,save)

if nargin < 6
    save = 'No';
    if nargin < 5
        tmult = 1;
        if nargin < 4
            id = .7;
            if nargin < 3
                od = .82;
            end
        end
    end
end

%% 1 - Load the image data
tic
disp('Loading image...')
ImageA = imread(fullpath);
info = imfinfo(fullpath);
switch info.ColorType
    case 'truecolor' %(RGB)
        ImageA = rgb2gray(ImageA);
end
I = im2double(ImageA);             % Convert to double
%figure, imshow(I), hold on;

% Generate the mask
disp('Generating the mask...')
[radius,yc,xc]=sizeMask(I,3,0); % Change 0 --> 1 for plotting
[BWmask]=makeMask(I,radius*od,yc,xc);
[BWmasksm]=makeMask(I,radius*id,yc,xc);

if source == 1      % Source == 1  --> Colony Image, needs inverting
    % Invert the image
    disp('Inverting the image...')
    O = ones(1200,1600);
    Inv = imsubtract(O,I);
else                % Otherwise, this is a plaque image - no inverting necessary
    Inv = I;
end

% Apply a light gaussian filter
disp('Applying a light gaussian filter...')
PSF = fspecial('gaussian',3,1);
F = imfilter(Inv,PSF,'symmetric','conv');

% Top hat the image
disp('Performing a top-hat...')
T = imtophat(F,strel('disk',20));
disp('Normalizing and removing text...')
if source == 1  % For an inverted colony image
    TCen = immultiply(T,BWmasksm);
    TNorm = T./max(max(TCen));
    Over = im2bw(TNorm,1);
    OD = imdilate(Over,strel('disk',10));
    BWM = BWmask &~OD;
else            % for a plaque image
    TCen = immultiply(T,BWmasksm);
    TNorm = T./min(min(TCen));
    Over = im2bw(TNorm,1);
    OD = imerode(Over,strel('disk',10));
    BWM = OD;
end

% Apply the ROI before doing to BW threshold
disp('Applying thresholds...')
X = immultiply(TNorm,im2double(BWM));
% Now threshold
% figure out the threshold only from the central area
avgin = sum(sum(immultiply(im2double(BWmasksm),TNorm)))/sum(sum(BWmasksm));
tholdx = graythresh(immultiply(im2double(BWmasksm),TNorm));
XBW = im2bw(X,tholdx*tmult);
% And clean up a bit
%XBWO = imopen(XBW,strel('disk',5));
XBWOC = bwmorph(XBW,'clean');
XBWOCD = bwdist(~XBWOC);

% And count
disp('Separating colonies....')
% ...by watershed
PW = XBWOCD; %immultiply(im2double(XBWOCD),im2double(F));
PW2 = -PW;
PW2(~XBWOC) = -Inf;
W = watershed(PW2);
W(find(W==1))=0;
[spotMapW,NWS] = bwlabel(W);

% % Comment this section to supress plotting
% colonyData1 = regionprops(spotMapW,'Centroid');
% cent = cat(1, colonyData1.Centroid);   % Centroid coordinates
% if ~isempty(cent)
%     plot(cent(:,1),cent(:,2),'r.','MarkerSize',11)
% end

% Save the results if the user specified so...
if strcmpi(save,'save')
    disp('Saving data...')
    saveCellImageData(fullpath,4,I,spotMapW)
    %saveCellImageData(fullfilepath,method,Original_Image,Label_Image)
end

count = NWS;
metric = tholdx/avgin;
time = toc;