function varargout = CameraAq(varargin)
% CAMERAAQ M-file for CameraAq.fig
%      CameraAq - allows for user interface for capturing and saving image
%      files from an attached camera.  Simply run the command CameraAq
%      without arguments - none are needed.
%      Output files are saved after pressing the Capture and Save button
%      These will overwrite any existing files with that name.
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CameraAq

% Last Modified by GUIDE v2.5 20-Jun-2008 09:10:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CameraAq_OpeningFcn, ...
                   'gui_OutputFcn',  @CameraAq_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% Initalize the camera
function CameraAq_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CameraAq (see VARARGIN)
global vid
% Choose default command line output for CameraAq
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CameraAq wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% If we were given a filepath and a filename when we were called update
% those, otherwise don't worry about it
if ~isempty(varargin)     % If we are given input arguments
    filepathcell=varargin{1}(1);
    filenamecell=varargin{1}(2);
    filepath = filepathcell{1};
    filename = filenamecell{1};
    set(handles.pathdisplay,'String',filepath);
    set(handles.namedisplay,'String',filename);
    clear filepathcell filenamecell filepath filename
    % Otherwise assume defaults
end

axes(handles.axes1);
axes(handles.axes2);
axis off

imgeninfo = imaqhwinfo;	                            % What adaptors are attached to the system
sources = imgeninfo.InstalledAdaptors;              % What adaptor options do we have
adapchoice = menu('Choose format',sources);         % Get the user's choice, usually 2 for winvideo
adaptorname = char(sources(adapchoice));                  % Ask the user which adaptor to use
info = imaqhwinfo(adaptorname);                      % Look up the general info about the adaptor
if length(info.DeviceIDs) == 1                      % Use the default if there's only one device
    dID = info.DeviceIDs;                            % Store the device ID
else                                                % Otherwise, get which device the user wants
    dChoice = menu(info.DeviceIDs);
    dID = info.DeviceIDs(dChoice);
end
dev_info = imaqhwinfo(adaptorname,1);                % Look up the device info, which contains the default format
%defaultformat = dev_info.DefaultFormat;             % Store the default format
supported = dev_info.SupportedFormats;              % Get the user's choice in video formats
formatchoice = menu('Choose format',supported); %9 for 1600x1200 RGB
vidformat = supported(formatchoice);
vid = videoinput(adaptorname,dID{1},vidformat{1});    % Create a video object with the properties we requested
%preview(vid)                    % Launch a preview window for us to see the video in

% Initalize the Camera and get the information
% Create an image object for previewing.
vidRes = get(vid, 'VideoResolution');
nBands = get(vid, 'NumberOfBands');
axes(handles.axes1);            % Grab onto the first axes
hImage = image( zeros(vidRes(2), vidRes(1), nBands) );  % Pad to the size of the camera
preview(vid, hImage);           % Preview in the embedded axes
triggerconfig(vid, 'Manual');   % Set trigger type to manual
set(vid,'FramesPerTrigger',1);  % Set the video to only capture one frame
% Turn of the damned face tracking
src=getselectedsource(vid);
src.TiltMode='manual';
src.ZoomMode='manual';
src.PanMode='manual';

% Update handles structure
%handles.vid = vid;
%guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = CameraAq_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%% Captures data, saves it and increases a counter
function capture_Callback(hObject, eventdata, handles)
global vid fullpath filename    % These variables were easiest to handle in a global format
start(vid)                      % Start the camera object
trigger(vid)                    % Trigger acquisition
get(vid,'FramesAcquired');      % Check that we got some frames
% video automatically stops after a trigger
Data = getdata(vid);            % Get the data from the video object

% Save the data
filepath = get(handles.pathdisplay,'String');
if iscell(filepath)
    filepath = filepath{1};
end
if filepath(length(filepath))~='\'      % Do a check that we have the last slash
    filepath = [filepath,'\'];
end
filename = get(handles.namedisplay,'String');
if iscell(filename)
    filename = filename{1};
end
number = get(handles.count,'String');
possibleextension = get(handles.extension,'String');
extension = possibleextension{get(handles.extension,'Value')};
fullpath = [filepath,filename,'_',number,extension];
imwrite(Data,fullpath);
handles.filename = filename;
handles.fullpath = fullpath;
% Update handles structure
guidata(hObject, handles);

% Increment the counter
num = str2num(number);  %  Just do the number, the letter was confusing...
num = num+1;
numbernew = num2str(num);
[r,dig] = size(number);
[r,dign] = size(numbernew);
for k = 1:dig-dign;
    numbernew = ['0',numbernew];
end
set(handles.count,'String',numbernew);
axes(handles.axes2);
imshow(Data);                   % Show the captured image

%% Captures and analyzes the data in one fell swoop
function capturecount_Callback(hObject, eventdata, handles)
global fullpath filename
% First run the capture callback
capture_Callback(hObject, eventdata, handles);
% This gets us the data from the camera
% Now find out which analysis method to use, and run that.
method = get(handles.countMethod,'Value');
% We make a few assumptions when running the following counter program.
%    1) That the user is happy with all default values.  For example, he's
%    counting colonies, and has a standard size for outer and inner
%    diameters, likes the threshold where it is, and doesn't want to save.
switch method
    case 1          % Use the HR watershed approach
        [numcol,time,metric] = Camera_HRwtsh(fullpath,1,.82,.7,1,'nosave');
    case 2          % Use the HR regional max method
        [numcol,time,metric] = Camera_HRwtsh(fullPath,1,.82,.7,1,'nosave');
end

%% Closes the window
function exit_Callback(hObject, eventdata, handles)
global vid          % Get our video object
delete(vid)         % And keep it from hanging around
clear vid           % just in case, as they should close automatically
close(gcf)          % when the figure closes

%% Functions that change the filepath and name
function filepath_Callback(hObject, eventdata, handles)
dir = uigetdir;
set(handles.pathdisplay,'String',dir);
function filename_Callback(hObject, eventdata, handles)
name = inputdlg('Filename','Save Options',1);
set(handles.namedisplay,'String',name);

%% Extra crap that GUIDE puts in
function count_Callback(hObject, eventdata, handles)
function count_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function extension_Callback(hObject, eventdata, handles)
function extension_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pathdisplay_Callback(hObject, eventdata, handles)
function pathdisplay_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function namedisplay_Callback(hObject, eventdata, handles)
function namedisplay_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function countMethod_Callback(hObject, eventdata, handles)
function countMethod_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function letter_Callback(hObject, eventdata, handles)
function letter_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
